// Copyright 2019 Graham Clark. All rights reserved.  Use of this source
// code is governed by the MIT license that can be found in the LICENSE
// file.

package termshark

var Version string = "<localbuild>"

//======================================================================
// Local Variables:
// indent-tabs-mode: nil
// tab-width: 4
// fill-column: 78
// End:
