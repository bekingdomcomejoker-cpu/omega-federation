
To re-generate:

$ go get github.com/rakyll/statik
$ statik -src=data
