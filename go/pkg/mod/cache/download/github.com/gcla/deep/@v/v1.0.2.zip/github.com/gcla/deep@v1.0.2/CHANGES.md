# go-test/deep Changelog

## v1.0.1 released 2018-01-28

* Fixed #12: Arrays are not properly compared (samlitowitz)

## v1.0.0 releaesd 2017-10-27 

* First release
